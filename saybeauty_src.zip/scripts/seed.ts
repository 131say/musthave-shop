// scripts/seed.ts
import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
import { PrismaBetterSqlite3 } from '@prisma/adapter-better-sqlite3';

const adapter = new PrismaBetterSqlite3({
  url: process.env.DATABASE_URL || 'file:./dev.db',
});

const prisma = new PrismaClient({ adapter });

async function main() {
  const products = [
    {
      name: 'COSRX Low pH Good Morning Gel Cleanser',
      slug: 'cosrx-low-ph-good-morning-gel-cleanser',
      description:
        'Мягкий гель для умывания с низким pH для ежедневного очищения без чувства стянутости.',
      price: 5500,
      costPrice: 3300,
      oldPrice: 6500,
      imageUrl: '/images/products/cosrx-cleanser.jpg',
    },
    {
      name: 'Some By Mi AHA BHA PHA 30 Days Miracle Toner',
      slug: 'some-by-mi-aha-bha-pha-miracle-toner',
      description:
        'Тонер с кислотами AHA/BHA/PHA для очищения пор, выравнивания рельефа и улучшения тона кожи.',
      price: 7200,
      costPrice: 4300,
      oldPrice: 8500,
      imageUrl: '/images/products/somebymi-toner.jpg',
    },
    {
      name: 'Laneige Water Sleeping Mask',
      slug: 'laneige-water-sleeping-mask',
      description:
        'Ночная увлажняющая маска, которая восстанавливает кожу во время сна и делает её более упругой и сияющей.',
      price: 9800,
      costPrice: 5900,
      oldPrice: null,
      imageUrl: '/images/products/laneige-mask.jpg',
    },
    {
      name: 'Innisfree Green Tea Seed Serum',
      slug: 'innisfree-green-tea-seed-serum',
      description:
        'Сыворотка с зелёным чаем для глубокого увлажнения и защиты кожи от окружающей среды.',
      price: 8900,
      costPrice: 5300,
      oldPrice: 9500,
      imageUrl: '/images/products/innisfree-serum.jpg',
    },
    {
      name: 'Etude House SoonJung 2x Barrier Intensive Cream',
      slug: 'etude-house-soonjung-intensive-cream',
      description:
        'Крем для чувствительной кожи с пантенолом и мадекассосидом, укрепляет защитный барьер.',
      price: 7600,
      costPrice: 4600,
      oldPrice: null,
      imageUrl: '/images/products/etude-cream.jpg',
    },
  ];

  for (const p of products) {
    await prisma.product.upsert({
      where: { slug: p.slug },
      update: p,
      create: {
        ...p,
        isActive: true,
      },
    });
  }

  console.log('✅ Seed completed: products created/updated');
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

