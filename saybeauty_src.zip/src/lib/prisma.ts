// src/lib/prisma.ts
import { PrismaClient } from '@prisma/client';
import { PrismaBetterSqlite3 } from '@prisma/adapter-better-sqlite3';

// Адаптер для SQLite (Prisma 7 требует adapter или accelerateUrl)
const adapter = new PrismaBetterSqlite3({
  // Prisma 7 больше не берёт url из schema.prisma,
  // но мы уже прописали его в prisma.config.ts и .env.
  // Здесь дублируем на всякий случай.
  url: process.env.DATABASE_URL || 'file:./dev.db',
});

// Глобальный singleton, чтобы не создавать клиента при каждом hot-reload
const globalForPrisma = globalThis as unknown as {
  prisma?: PrismaClient;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    adapter,
    log: ['warn', 'error'],
  });

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}
