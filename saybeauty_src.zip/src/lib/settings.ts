import { prisma } from "@/lib/prisma";

export type Settings = {
  customerPercent: number; // %
  inviterPercent: number; // %
  allowFullBonusPay: boolean;
};

export async function getSettings(): Promise<Settings> {
  const row = await prisma.appSettings.upsert({
    where: { id: 1 },
    update: {},
    create: { id: 1 },
  });
  return {
    customerPercent: row.customerPercent,
    inviterPercent: row.inviterPercent,
    allowFullBonusPay: row.allowFullBonusPay,
  };
}
