// src/lib/stats.ts
import { prisma } from "@/lib/prisma";

function toISODate(d: Date) {
  return d.toISOString().slice(0, 10);
}

export async function getStats(days: number) {
  const now = new Date();
  const from = new Date(now);
  from.setDate(from.getDate() - (days - 1));
  from.setHours(0, 0, 0, 0);

  // Берём заказы за период, исключаем отменённые
  const orders = await prisma.order.findMany({
    where: {
      createdAt: { gte: from },
      status: { not: 'CANCELLED' },
    },
    include: {
      items: {
        include: { product: { select: { costPrice: true } } },
      },
      referralEvents: true,
    },
    orderBy: { createdAt: 'asc' },
  });

  let revenue = 0;
  let cogs = 0; // себестоимость
  let bonusIssued = 0;
  let bonusSpent = 0;

  const daily: Record<
    string,
    { date: string; revenue: number; orders: number; cogs: number; bonusIssued: number; bonusSpent: number }
  > = {};

  for (const o of orders) {
    const date = toISODate(o.createdAt);
    daily[date] ??= { date, revenue: 0, orders: 0, cogs: 0, bonusIssued: 0, bonusSpent: 0 };

    const orderRevenue = o.totalAmount;
    let orderCogs = 0;
    for (const it of o.items) {
      const cp = it.product?.costPrice ?? 0;
      orderCogs += cp * it.quantity;
    }

    const issued = (o.referralEvents || [])
      .filter((e) => e.type === 'ORDER_BONUS' || e.type === 'SIGNUP_BONUS')
      .reduce((s, e) => s + (e.amount ?? 0), 0);
    const spent = (o.referralEvents || [])
      .filter((e) => e.type === 'BONUS_SPENT')
      .reduce((s, e) => s + (e.amount ?? 0), 0);

    revenue += orderRevenue;
    cogs += orderCogs;
    bonusIssued += issued;
    bonusSpent += spent;

    daily[date].revenue += orderRevenue;
    daily[date].orders += 1;
    daily[date].cogs += orderCogs;
    daily[date].bonusIssued += issued;
    daily[date].bonusSpent += spent;
  }

  const grossProfit = revenue - cogs;
  const netProfit = grossProfit - bonusIssued;
  const bonusLiability = bonusIssued - bonusSpent;

  const avgCheck = orders.length ? Math.round(revenue / orders.length) : 0;

  const series = Object.values(daily).sort((a, b) => a.date.localeCompare(b.date));

  return {
    ok: true,
    range: { days, from: from.toISOString(), to: now.toISOString() },
    kpis: {
      orders: orders.length,
      revenue,
      cogs,
      grossProfit,
      bonusIssued,
      bonusSpent,
      bonusLiability,
      netProfit,
      avgCheck,
    },
    series,
  };
}

