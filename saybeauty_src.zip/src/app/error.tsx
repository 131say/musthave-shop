'use client';

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html>
      <body style={{ padding: 24, fontFamily: 'system-ui' }}>
        <h2>Ошибка приложения</h2>
        <pre
          style={{
            whiteSpace: 'pre-wrap',
            background: '#111',
            color: '#0f0',
            padding: 12,
            borderRadius: 8,
          }}
        >
          {String(error?.message || error)}
          {'\n'}
          {error?.stack || ''}
          {'\n'}
          digest: {error?.digest || '—'}
        </pre>
        <button onClick={() => reset()} style={{ marginTop: 12, padding: '8px 12px' }}>
          Повторить
        </button>
      </body>
    </html>
  );
}
