// src/app/page.tsx
'use client';

import { FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: login, // используем login как "phone"
          password,
        }),
      });

      const text = await res.text();
      let data: any = null;
      try {
        data = text ? JSON.parse(text) : null;
      } catch {
        data = null;
      }

      if (!res.ok) {
        setError(data?.error || 'Ошибка входа');
        return;
      }

      const role = data?.role as 'ADMIN' | 'CUSTOMER' | undefined;

      if (role) {
        localStorage.setItem('role', role);
      }

      if (role === 'ADMIN') {
        router.replace('/admin/orders');
      } else {
        router.replace('/home');
      }
    } catch (err: any) {
      setError(err?.message || 'Ошибка сети');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-rose-50 to-white px-4">
      <div className="w-full max-w-md space-y-4 rounded-3xl border border-rose-100 bg-white/90 p-6 shadow-sm shadow-rose-100">
        <div className="space-y-1 text-center">
          <div className="inline-flex items-center justify-center gap-2 rounded-full bg-rose-50 px-3 py-1 text-[11px] text-rose-500">
            <span className="h-1.5 w-1.5 rounded-full bg-rose-400" />
            <span>K-Beauty • Kazakhstan</span>
          </div>
          <h1 className="text-xl font-semibold tracking-tight">SayBeauty</h1>
          <p className="text-xs text-slate-500">
            Вход в магазин и личный кабинет. Для теста: admin/admin или
            client/client.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="space-y-1">
            <label className="text-xs text-slate-500">Логин*</label>
            <input
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none ring-rose-100 focus:ring"
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              placeholder="admin или client"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs text-slate-500">Пароль*</label>
            <input
              type="password"
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none ring-rose-100 focus:ring"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="пароль"
            />
          </div>

          {error && (
            <p className="text-xs text-red-500 bg-red-50 border border-red-100 rounded-xl px-3 py-2">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading || !login || !password}
            className="w-full rounded-full bg-rose-500 px-4 py-2.5 text-sm font-medium text-white shadow-sm shadow-rose-200 transition hover:bg-rose-600 disabled:cursor-not-allowed disabled:bg-slate-300"
          >
            {loading ? 'Входим...' : 'Продолжить'}
          </button>
        </form>
      </div>
    </div>
  );
}
