// src/app/(site)/checkout/page.tsx
'use client';

import { FormEvent, useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { useCart } from '@/components/cart/CartProvider';

export default function CheckoutPage() {
  const { items, totalAmount, totalQuantity, clearCart, setQuantity, removeItem } =
    useCart();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [comment, setComment] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [bonusBalance, setBonusBalance] = useState(0);
  const [bonusToSpend, setBonusToSpend] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Загрузка баланса бонусов при вводе телефона
  useEffect(() => {
    const p = phone.trim();
    if (!p) {
      setBonusBalance(0);
      setBonusToSpend(0);
      return;
    }
    const t = setTimeout(async () => {
      try {
        const res = await fetch('/api/profile', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: p }),
        });
        const data = await res.json().catch(() => null);
        if (!res.ok || !data?.profile) {
          setBonusBalance(0);
          setBonusToSpend(0);
          return;
        }
        const bal = Number(data.profile.bonusBalance || 0);
        setBonusBalance(bal);
        setBonusToSpend((prev) => Math.min(prev, bal, totalAmount));
      } catch {
        setBonusBalance(0);
        setBonusToSpend(0);
      }
    }, 350);
    return () => clearTimeout(t);
  }, [phone, totalAmount]);

  const maxSpend = Math.min(bonusBalance, totalAmount);
  const cashToPay = Math.max(0, totalAmount - Math.min(bonusToSpend, maxSpend));
  const spendSafe = Math.min(bonusToSpend, maxSpend);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!items.length) {
      setError('Корзина пуста');
      return;
    }
    if (!name || !phone) {
      setError('Заполни имя и телефон');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: name,
          customerPhone: phone,
          customerAddress: address,
          comment,
          referralCode,
          bonusToSpend: spendSafe,
          items: items.map((i) => ({
            productId: i.productId,
            quantity: i.quantity,
            price: i.price,
          })),
        }),
      });

      if (!res.ok) {
        throw new Error('Ошибка при оформлении заказа');
      }

      clearCart();
      setSuccess('Заказ оформлен! Мы свяжемся с тобой для подтверждения.');
      setName('');
      setPhone('');
      setAddress('');
      setComment('');
      setReferralCode('');
      setBonusToSpend(0);
    } catch (err: any) {
      setError(err.message || 'Что-то пошло не так');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-[1.5fr,1fr]">
      <section className="space-y-4">
        <h2 className="text-lg font-semibold">Оформление заказа</h2>

        {items.length === 0 ? (
          <p className="text-sm text-slate-500">
            Корзина пуста. Вернись в каталог и добавь товары.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1">
                <label className="text-xs text-slate-500">Имя*</label>
                <input
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none ring-rose-100 focus:ring"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Как к тебе обращаться?"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-slate-500">Телефон*</label>
                <input
                  className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none ring-rose-100 focus:ring"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+7 ..."
                />
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <div className="flex items-center justify-between">
                <div className="text-xs font-semibold text-slate-600">Бонусы</div>
                <div className="text-xs text-slate-600">Баланс: {bonusBalance} ₸</div>
              </div>
              <div className="mt-3">
                <div className="text-xs text-slate-500">Списать (0…{maxSpend} ₸)</div>
                <div className="mt-2 flex items-center gap-2">
                  <input
                    type="number"
                    value={bonusToSpend}
                    onChange={(e) =>
                      setBonusToSpend(
                        Math.max(0, Math.min(Number(e.target.value || 0), maxSpend)),
                      )
                    }
                    className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
                    placeholder="0"
                  />
                  <button
                    type="button"
                    onClick={() => setBonusToSpend(maxSpend)}
                    className="whitespace-nowrap rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs hover:bg-slate-50"
                  >
                    Максимум
                  </button>
                </div>
                <div className="mt-2 text-xs text-slate-600">
                  К оплате: <span className="font-semibold">{cashToPay} ₸</span>
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs text-slate-500">Реферальный код (необязательно)</label>
              <input
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none ring-rose-100 focus:ring"
                value={referralCode}
                onChange={(e) => setReferralCode(e.target.value)}
                placeholder="Например: SAY1234"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-slate-500">
                Город / адрес доставки
              </label>
              <input
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none ring-rose-100 focus:ring"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Например: Алматы, Бостандыкский район..."
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-slate-500">
                Комментарий к заказу
              </label>
              <textarea
                className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none ring-rose-100 focus:ring"
                rows={3}
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Удобное время звонка, подъезд, домофон и т.д."
              />
            </div>

            {error && (
              <p className="text-xs text-red-500 bg-red-50 border border-red-100 rounded-xl px-3 py-2">
                {error}
              </p>
            )}
            {success && (
              <p className="text-xs text-emerald-600 bg-emerald-50 border border-emerald-100 rounded-xl px-3 py-2">
                {success}
              </p>
            )}

            <button
              type="submit"
              disabled={
                isSubmitting ||
                !items.length ||
                !name.trim() ||
                !phone.trim() ||
                !address.trim() ||
                cashToPay < 0
              }
              className="w-full rounded-full bg-rose-500 px-4 py-2.5 text-sm font-medium text-white shadow-sm shadow-rose-200 transition hover:bg-rose-600 disabled:cursor-not-allowed disabled:bg-slate-300"
            >
              {isSubmitting ? 'Оформляем заказ...' : 'Оформить заказ'}
            </button>
          </form>
        )}
      </section>

      <section className="space-y-4 rounded-3xl border border-rose-100 bg-white/80 p-4 shadow-sm shadow-rose-50">
        <h3 className="text-sm font-semibold">Твои товары</h3>
        {items.length === 0 ? (
          <p className="text-sm text-slate-500">Пока пусто.</p>
        ) : (
          <>
            <ul className="space-y-3 text-sm">
              {items.map((item) => (
                <li
                  key={item.productId}
                  className="flex items-start justify-between gap-3"
                >
                  <div className="flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium">{item.name}</span>
                      <button
                        type="button"
                        onClick={() => removeItem(item.productId)}
                        className="text-[11px] text-slate-400 hover:text-rose-500"
                      >
                        убрать
                      </button>
                    </div>
                    <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-500">
                      <span>
                        {item.price.toLocaleString('ru-RU')} ₸ ×
                      </span>
                      <input
                        type="number"
                        min={1}
                        value={item.quantity}
                        onChange={(e) =>
                          setQuantity(
                            item.productId,
                            Number(e.target.value) || 1,
                          )
                        }
                        className="w-12 rounded-md border border-slate-200 bg-white px-1 py-0.5 text-center text-[11px] outline-none"
                      />
                    </div>
                  </div>
                  <div className="text-xs font-semibold text-slate-800">
                    {(item.price * item.quantity).toLocaleString('ru-RU')} ₸
                  </div>
                </li>
              ))}
            </ul>
            <div className="mt-4 border-t border-rose-100 pt-3 text-sm">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Товаров</span>
                <span>{totalQuantity}</span>
              </div>
              <div className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-600">Итого</span>
                  <span className="font-semibold">{totalAmount.toLocaleString('ru-RU')} ₸</span>
                </div>
                {spendSafe > 0 && (
                  <div className="flex items-center justify-between text-xs text-slate-600">
                    <span>Оплачено бонусами</span>
                    <span className="font-semibold text-emerald-700">−{spendSafe.toLocaleString('ru-RU')} ₸</span>
                  </div>
                )}
                <div className="flex items-center justify-between text-base">
                  <span className="font-medium">К оплате</span>
                  <span className="font-semibold">{cashToPay.toLocaleString('ru-RU')} ₸</span>
                </div>
              </div>
            </div>
          </>
        )}
      </section>
    </div>
  );
}

