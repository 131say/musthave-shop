// src/app/(site)/cabinet/page.tsx
'use client';

import { FormEvent, useState } from 'react';

type ReferralEvent = {
  id: number;
  type: string;
  amount: number;
  orderId: number | null;
  note: string | null;
  createdAt: string;
};

type Order = {
  id: number;
  totalAmount: number;
  status: string;
  createdAt: string;
};

type ProfileResponse = {
  id: number;
  name: string | null;
  phone: string;
  referralCode: string;
  bonusBalance: number;
  referredBy: {
    id: number;
    name: string | null;
    phone: string;
    referralCode: string;
  } | null;
  referrals: {
    id: number;
    name: string | null;
    phone: string;
    referralCode: string;
  }[];
  referralEvents: ReferralEvent[];
  orders: Order[];
};

export default function CabinetPage() {
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [profile, setProfile] = useState<ProfileResponse | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setProfile(null);

    if (!phone && !code) {
      setError('Введи телефон или реферальный код');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: phone || undefined,
          referralCode: code || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || 'Ошибка загрузки профиля');
        return;
      }

      setProfile(data);
    } catch (err: any) {
      setError(err.message || 'Ошибка сети');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <section className="space-y-3">
        <h2 className="text-lg font-semibold">Мой кабинет</h2>
        <p className="text-sm text-slate-500">
          Введи номер телефона, который указывал при заказе, или свой
          реферальный код, чтобы посмотреть баланс и приглашённых.
        </p>
        <form
          onSubmit={handleSubmit}
          className="grid gap-3 rounded-2xl border border-rose-100 bg-white/80 p-4 sm:grid-cols-[2fr,2fr,1.2fr]"
        >
          <div className="space-y-1">
            <label className="text-xs text-slate-500">
              Телефон (как в заказе)
            </label>
            <input
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none ring-rose-100 focus:ring"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+7 ..."
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs text-slate-500">
              Реферальный код (например: SAY1001)
            </label>
            <input
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none ring-rose-100 focus:ring"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="SAY1xxx"
            />
          </div>
          <div className="flex items-end">
            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-full bg-rose-500 px-4 py-2.5 text-sm font-medium text-white shadow-sm shadow-rose-200 transition hover:bg-rose-600 disabled:cursor-not-allowed disabled:bg-slate-300"
            >
              {loading ? 'Ищем...' : 'Показать кабинет'}
            </button>
          </div>
        </form>
        {error && (
          <p className="text-xs text-red-500 bg-red-50 border border-red-100 rounded-xl px-3 py-2">
            {error}
          </p>
        )}
      </section>

      {profile && (
        <section className="space-y-4">
          <div className="grid gap-4 md:grid-cols-[1.4fr,1.6fr]">
            <div className="space-y-3 rounded-2xl border border-rose-100 bg-gradient-to-br from-rose-50 to-white p-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <div className="text-xs text-slate-400">Имя</div>
                  <div className="text-sm font-semibold">
                    {profile.name || 'Без имени'}
                  </div>
                  <div className="text-xs text-slate-500">
                    {profile.phone}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-400">Баланс бонусов</div>
                  <div className="text-base font-semibold text-emerald-600">
                    {profile.bonusBalance.toLocaleString('ru-RU')} ₸
                  </div>
                </div>
              </div>
              <div className="rounded-xl bg-white/80 px-3 py-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Твой реферальный код</span>
                  <span className="rounded-full bg-rose-100 px-3 py-1 text-[11px] font-semibold text-rose-600">
                    {profile.referralCode}
                  </span>
                </div>
                <p className="mt-2 text-[11px] text-slate-500">
                  Поделись этим кодом с друзьями. Они укажут его при заказе, а
                  ты будешь получать бонусы.
                </p>
              </div>

              {profile.referredBy ? (
                <div className="rounded-xl bg-emerald-50/60 px-3 py-2 text-[11px] text-slate-700">
                  <div className="font-semibold">Тебя пригласил</div>
                  <div>
                    {profile.referredBy.name || profile.referredBy.phone}{' '}
                    <span className="text-slate-400">
                      ({profile.referredBy.referralCode})
                    </span>
                  </div>
                </div>
              ) : (
                <div className="rounded-xl bg-slate-50 px-3 py-2 text-[11px] text-slate-500">
                  Ты пришёл сам, без пригласителя.
                </div>
              )}
            </div>

            <div className="space-y-3 rounded-2xl border border-rose-100 bg-white/80 p-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Приглашённые</h3>
                <span className="text-[11px] text-slate-500">
                  {profile.referrals.length}
                </span>
              </div>
              {profile.referrals.length === 0 ? (
                <p className="text-[11px] text-slate-500">
                  Пока никого нет. Начни с того, что поделишься своим кодом.
                </p>
              ) : (
                <ul className="space-y-1.5 text-xs">
                  {profile.referrals.map((r) => (
                    <li
                      key={r.id}
                      className="flex items-center justify-between gap-2"
                    >
                      <div>
                        <div className="font-medium">
                          {r.name || r.phone}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {r.phone} · {r.referralCode}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-[1.5fr,1.5fr]">
            <div className="space-y-2 rounded-2xl border border-slate-200 bg-white/80 p-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">История заказов</h3>
                <span className="text-[11px] text-slate-500">
                  {profile.orders.length}
                </span>
              </div>
              {profile.orders.length === 0 ? (
                <p className="text-[11px] text-slate-500">
                  Ты ещё не делал заказы.
                </p>
              ) : (
                <ul className="space-y-1.5 text-xs">
                  {profile.orders.map((o) => (
                    <li
                      key={o.id}
                      className="flex items-center justify-between gap-2"
                    >
                      <div>
                        <div className="font-medium">
                          Заказ №{o.id}{' '}
                          <span className="text-[10px] uppercase text-slate-400">
                            {o.status}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {new Date(o.createdAt).toLocaleString('ru-RU')}
                        </div>
                      </div>
                      <div className="text-[11px] font-semibold text-slate-800">
                        {o.totalAmount.toLocaleString('ru-RU')} ₸
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="space-y-2 rounded-2xl border border-slate-200 bg-white/80 p-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">История бонусов</h3>
                <span className="text-[11px] text-slate-500">
                  {profile.referralEvents.length}
                </span>
              </div>
              {profile.referralEvents.length === 0 ? (
                <p className="text-[11px] text-slate-500">
                  Бонусов пока нет.
                </p>
              ) : (
                <ul className="space-y-1.5 text-xs">
                  {profile.referralEvents.map((e) => (
                    <li
                      key={e.id}
                      className="flex items-center justify-between gap-2"
                    >
                      <div>
                        <div className="font-medium">
                          {e.type === 'ORDER_BONUS'
                            ? 'Бонус за заказ'
                            : e.type === 'SIGNUP_BONUS'
                            ? 'Бонус за приглашение'
                            : e.type}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {e.orderId ? `Заказ №${e.orderId} · ` : ''}
                          {new Date(e.createdAt).toLocaleString('ru-RU')}
                        </div>
                        {e.note && (
                          <div className="text-[11px] text-slate-400">
                            {e.note}
                          </div>
                        )}
                      </div>
                      <div
                        className={
                          'text-[11px] font-semibold ' +
                          (e.amount >= 0 ? 'text-emerald-600' : 'text-red-500')
                        }
                      >
                        {e.amount >= 0 ? '+' : ''}
                        {e.amount.toLocaleString('ru-RU')} ₸
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
