// src/app/(site)/layout.tsx
import { CartProvider } from '@/components/cart/CartProvider';
import Link from 'next/link';
import { CartBadge } from '@/components/cart/CartBadge';

export default function SiteLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <CartProvider>
      <div className="mx-auto max-w-5xl px-4 py-6">
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-rose-100 pb-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 rounded-full bg-rose-50 px-3 py-1">
              <span className="h-1.5 w-1.5 rounded-full bg-rose-400" />
              <span className="text-xs font-medium text-rose-500">
                K-Beauty • Kazakhstan
              </span>
            </div>
            <Link href="/home" className="block">
              <h1 className="text-2xl font-semibold tracking-tight">
                SayBeauty
              </h1>
            </Link>
            <p className="text-sm text-slate-500">
              Корейская косметика с доставкой по всему Казахстану и
              реферальной программой.
            </p>
          </div>
          <nav className="flex items-center gap-3 text-xs text-slate-600">
            <Link
              href="/home"
              className="rounded-full border border-rose-100 px-4 py-1.5 hover:bg-rose-50"
            >
              Каталог
            </Link>
            <button className="rounded-full border border-rose-100 px-4 py-1.5 hover:bg-rose-50">
              Бонусы
            </button>
            <Link
              href="/cabinet"
              className="rounded-full border border-rose-100 px-4 py-1.5 hover:bg-rose-50"
            >
              Мой кабинет
            </Link>
            <Link
              href="/checkout"
              className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-4 py-1.5 hover:bg-slate-50"
            >
              <CartBadge />
              <span>Корзина</span>
            </Link>
          </nav>
        </header>
        <main className="pt-6">{children}</main>
      </div>
    </CartProvider>
  );
}
