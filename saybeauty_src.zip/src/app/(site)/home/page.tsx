// src/app/(site)/home/page.tsx
import { prisma } from '@/lib/prisma';
import { ProductGrid } from '@/components/ProductGrid';
import NewsBlock from '@/components/NewsBlock';

export default async function HomePage() {
  const products = await prisma.product.findMany({
    where: { isActive: true },
    orderBy: { createdAt: 'desc' },
  });

  return (
    <div className="space-y-8">
      <NewsBlock />
      <section className="grid gap-6 rounded-3xl bg-gradient-to-r from-rose-50 to-rose-100 p-6 sm:grid-cols-[2fr,1.2fr]">
        <div className="space-y-3">
          <h2 className="text-xl font-semibold leading-tight">
            Корейский уход,{' '}
            <span className="text-rose-500">который хочется повторять</span>
          </h2>
          <p className="text-sm text-slate-600">
            Подборка проверенной корейской косметики с доставкой по всему
            Казахстану. Копи бонусы, делись реферальным кодом и экономь на
            каждом заказе.
          </p>
          <div className="flex flex-wrap gap-3 text-xs">
            <span className="rounded-full bg-white/80 px-3 py-1">
              + бонусы за каждый заказ
            </span>
            <span className="rounded-full bg-white/80 px-3 py-1">
              доставка по Казахстану
            </span>
            <span className="rounded-full bg-white/80 px-3 py-1">
              оригинальная продукция
            </span>
          </div>
        </div>
        <div className="flex items-center justify-center">
          <div className="relative h-32 w-32 sm:h-40 sm:w-40">
            <div className="absolute inset-0 rounded-3xl bg-white/70 shadow-lg shadow-rose-100" />
            <div className="absolute inset-3 rounded-2xl border border-dashed border-rose-200" />
            <div className="absolute inset-6 flex items-center justify-center text-center text-[11px] text-slate-500">
              Здесь позже будет красивая промо-картинка
              <br />
              или баннер 💄
            </div>
          </div>
        </div>
      </section>

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Популярные средства</h3>
          <span className="text-xs text-rose-500">
            Нажми «В корзину», чтобы добавить товар
          </span>
        </div>

        <ProductGrid products={products} />
      </section>
    </div>
  );
}

