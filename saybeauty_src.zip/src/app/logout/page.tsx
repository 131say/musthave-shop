// src/app/logout/page.tsx
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function LogoutPage() {
  const router = useRouter();

  useEffect(() => {
    const doLogout = async () => {
      try {
        await fetch('/api/auth/logout', { method: 'POST' });
      } catch (e) {
        // игнорируем, главное — убрать куки на сервере
      } finally {
        router.replace('/');
      }
    };

    doLogout();
  }, [router]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-rose-50 to-white px-4">
      <div className="rounded-3xl border border-rose-100 bg-white/90 px-6 py-4 text-sm text-slate-500 shadow-sm shadow-rose-100">
        Выходим из аккаунта...
      </div>
    </div>
  );
}
