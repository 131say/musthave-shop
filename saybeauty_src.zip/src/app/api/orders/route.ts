// src/app/api/orders/route.ts
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSettings } from '@/lib/settings';

// percents are loaded from AppSettings (defaults: 3% / 5%)

function generateReferralCode(userId: number) {
  return `SAY${1000 + userId}`;
}

function clampInt(n: unknown, min: number, max: number) {
  const v = typeof n === 'number' ? Math.floor(n) : Number(n);
  if (!Number.isFinite(v)) return min;
  return Math.max(min, Math.min(max, v));
}

export async function POST(req: Request) {
  try {
    const settings = await getSettings();
    const INVITER_PERCENT = settings.inviterPercent / 100;
    const CUSTOMER_PERCENT = settings.customerPercent / 100;

    const body = await req.json();

    const {
      customerName,
      customerPhone,
      customerAddress,
      comment,
      referralCode,
      items,
      bonusToSpend,
    } = body as {
      customerName: string;
      customerPhone: string;
      customerAddress?: string;
      comment?: string;
      referralCode?: string;
      items: { productId: number; quantity: number; price: number }[];
      bonusToSpend?: number;
    };

    if (!customerName || !customerPhone) {
      return NextResponse.json(
        { error: 'Имя и телефон обязательны' },
        { status: 400 },
      );
    }

    if (!items || !items.length) {
      return NextResponse.json(
        { error: 'Корзина пуста' },
        { status: 400 },
      );
    }

    const result = await prisma.$transaction(async (tx) => {
      // 1) Ищем или создаём пользователя по телефону
      let user = await tx.user.findUnique({
        where: { phone: customerPhone },
      });

      if (!user) {
        // Создаём пользователя с временным кодом, потом обновим
        user = await tx.user.create({
          data: {
            phone: customerPhone,
            name: customerName,
            referralCode: `TEMP${Date.now()}`, // временный код
          },
        });

        const code = generateReferralCode(user.id);

        user = await tx.user.update({
          where: { id: user.id },
          data: { referralCode: code },
        });
      }

      // 2) Привязка по реферальному коду (если ещё не привязан)
      let inviter = null as null | typeof user;

      if (referralCode && user.referredByUserId == null) {
        inviter = await tx.user.findUnique({
          where: { referralCode },
        });

        if (inviter && inviter.id !== user.id) {
          user = await tx.user.update({
            where: { id: user.id },
            data: { referredByUserId: inviter.id },
          });

          await tx.referralEvent.create({
            data: {
              userId: inviter.id,
              referredUserId: user.id,
              type: 'SIGNUP_BONUS',
              amount: 0, // можно будет изменить на фиксированный бонус за регистрацию
              note: 'Пользователь зарегистрирован по реферальному коду',
            },
          });
        }
      } else if (user.referredByUserId != null) {
        inviter = await tx.user.findUnique({
          where: { id: user.referredByUserId },
        });
      }

      // 3) Рассчитываем сумму заказа
      const totalAmount = items.reduce(
        (sum, i) => sum + i.price * i.quantity,
        0,
      );

      // 4) Рассчитываем списание бонусов
      const maxSpendRaw = Math.min(user.bonusBalance ?? 0, totalAmount);
      const maxSpend = settings.allowFullBonusPay ? maxSpendRaw : Math.floor(totalAmount * 0.5);
      const spend = clampInt(bonusToSpend ?? 0, 0, maxSpend);
      const cashPaid = totalAmount - spend;

      // 5) Создаём заказ
      const order = await tx.order.create({
        data: {
          userId: user.id,
          customerName,
          customerPhone,
          customerAddress,
          comment,
          status: 'NEW',
          totalAmount,
          bonusSpent: spend,
          cashPaid,
          items: {
            create: items.map((i) => ({
              productId: i.productId,
              quantity: i.quantity,
              priceAtMoment: i.price,
              subtotal: i.price * i.quantity,
            })),
          },
        } as any,
        select: { id: true },
      });

      // 6) Списываем бонусы, если есть
      if (spend > 0) {
        await tx.user.update({
          where: { id: user.id },
          data: { bonusBalance: { decrement: spend } },
        });
        await tx.referralEvent.create({
          data: {
            type: 'BONUS_SPENT' as any,
            amount: spend,
            userId: user.id,
            referredUserId: null,
            orderId: order.id,
            note: 'Списание бонусов при оплате заказа',
          },
        });
      }

      // 7) Рассчитываем и начисляем бонусы
      const inviterBonus = inviter
        ? Math.round(totalAmount * INVITER_PERCENT)
        : 0;
      const customerBonus = Math.round(totalAmount * CUSTOMER_PERCENT);

      // Бонус покупателю
      if (customerBonus > 0) {
        await tx.user.update({
          where: { id: user.id },
          data: {
            bonusBalance: { increment: customerBonus },
          },
        });

        await tx.referralEvent.create({
          data: {
            userId: user.id,
            referredUserId: null,
            orderId: order.id,
            type: 'ORDER_BONUS',
            amount: customerBonus,
            note: 'Кэшбэк за заказ',
          },
        });
      }

      // Бонус пригласителю (если есть)
      if (inviter && inviterBonus > 0) {
        await tx.user.update({
          where: { id: inviter.id },
          data: {
            bonusBalance: { increment: inviterBonus },
          },
        });

        await tx.referralEvent.create({
          data: {
            userId: inviter.id,
            referredUserId: user.id,
            orderId: order.id,
            type: 'ORDER_BONUS',
            amount: inviterBonus,
            note: 'Бонус за заказ приглашённого',
          },
        });
      }

      return {
        ok: true,
        orderId: order.id,
        totalAmount,
        bonusSpent: spend,
        cashPaid,
      };
    });

    return NextResponse.json(result);
  } catch (err) {
    console.error('Order create error', err);
    return NextResponse.json(
      { error: 'Ошибка сервера при создании заказа' },
      { status: 500 },
    );
  }
}
