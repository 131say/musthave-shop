import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const { orderId, status } = (body || {}) as {
      orderId?: number;
      status?: 'NEW' | 'PROCESSING' | 'DONE' | 'CANCELLED';
    };

    if (!orderId || !status) {
      return NextResponse.json(
        { error: 'orderId и status обязательны' },
        { status: 400 },
      );
    }

    const updated = await prisma.order.update({
      where: { id: orderId },
      data: { status },
    });

    return NextResponse.json({ ok: true, order: updated });
  } catch (e) {
    console.error('orders/status error', e);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 },
    );
  }
}
