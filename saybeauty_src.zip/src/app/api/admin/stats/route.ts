import { NextResponse } from 'next/server';
import { getStats } from '@/lib/stats';

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const days = Math.max(1, Math.min(90, Number(url.searchParams.get('days') || 14)));

    const stats = await getStats(days);
    return NextResponse.json(stats);
  } catch (e) {
    console.error('stats error', e);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 },
    );
  }
}
