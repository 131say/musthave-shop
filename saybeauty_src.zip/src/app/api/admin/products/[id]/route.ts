import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

function slugify(input: string) {
  return input
    .toLowerCase()
    .trim()
    .replace(/[\s_]+/g, '-')
    .replace(/[^a-z0-9\-]+/g, '')
    .replace(/\-+/g, '-')
    .replace(/^\-+|\-+$/g, '');
}

async function ensureUniqueSlug(base: string, excludeId?: number) {
  let slug = base || 'product';
  let i = 1;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const found = await prisma.product.findFirst({
      where: excludeId
        ? { slug, NOT: { id: excludeId } }
        : { slug },
      select: { id: true },
    });
    if (!found) return slug;
    i += 1;
    slug = `${base}-${i}`;
  }
}

export async function GET(
  _req: Request,
  ctx: { params: Promise<{ id: string }> },
) {
  try {
    const params = await ctx.params;
    const id = Number(params.id);
    if (!id || Number.isNaN(id)) {
      return NextResponse.json({ error: 'Некорректный id' }, { status: 400 });
    }

    const product = await prisma.product.findUnique({ where: { id } });
    if (!product) {
      return NextResponse.json({ error: 'Товар не найден' }, { status: 404 });
    }

    return NextResponse.json({ ok: true, product });
  } catch (e) {
    console.error('admin/products/[id] GET error', e);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 },
    );
  }
}

export async function POST(
  req: Request,
  ctx: { params: Promise<{ id: string }> },
) {
  try {
    const params = await ctx.params;
    const id = Number(params.id);
    if (!id || Number.isNaN(id)) {
      return NextResponse.json({ error: 'Некорректный id' }, { status: 400 });
    }

    const body = await req.json().catch(() => null);
    const {
      name,
      description,
      price,
      costPrice,
      oldPrice,
      imageUrl,
      isActive,
    } = (body || {}) as {
      name?: string;
      description?: string;
      price?: number;
      costPrice?: number;
      oldPrice?: number | null;
      imageUrl?: string | null;
      isActive?: boolean;
    };

    if (!name || typeof price !== 'number' || typeof costPrice !== 'number') {
      return NextResponse.json(
        { error: 'name, price и costPrice обязательны' },
        { status: 400 },
      );
    }

    const base = slugify(name);
    const slug = await ensureUniqueSlug(base, id);

    const product = await prisma.product.update({
      where: { id },
      data: {
        name,
        description: description || '',
        price: Math.round(price),
        costPrice: Math.round(costPrice),
        oldPrice: oldPrice == null ? null : Math.round(oldPrice),
        imageUrl: imageUrl || null,
        isActive: isActive ?? true,
        slug,
      },
    });

    return NextResponse.json({ ok: true, product });
  } catch (e) {
    console.error('admin/products/[id] POST error', e);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 },
    );
  }
}

export async function DELETE(
  _req: Request,
  ctx: { params: Promise<{ id: string }> },
) {
  try {
    const params = await ctx.params;
    const id = Number(params.id);
    if (!id || Number.isNaN(id)) {
      return NextResponse.json({ error: 'Некорректный id' }, { status: 400 });
    }

    await prisma.product.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error('admin/products/[id] DELETE error', e);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 },
    );
  }
}
