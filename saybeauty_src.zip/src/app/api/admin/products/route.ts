// src/app/api/admin/products/route.ts
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '') // убираем спецсимволы
    .replace(/[\s_-]+/g, '-') // заменяем пробелы и подчёркивания на дефисы
    .replace(/^-+|-+$/g, ''); // убираем дефисы в начале и конце
}

async function getUniqueSlug(baseSlug: string): Promise<string> {
  let slug = baseSlug;
  let counter = 1;

  while (true) {
    const existing = await prisma.product.findUnique({
      where: { slug },
    });

    if (!existing) {
      return slug;
    }

    slug = `${baseSlug}-${counter}`;
    counter++;
  }
}

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const q = (url.searchParams.get('q') || '').trim();
    const status = (url.searchParams.get('status') || 'ALL').trim();

    const where: any = {};

    if (q) {
      where.OR = [
        { name: { contains: q, mode: 'insensitive' } },
        { description: { contains: q, mode: 'insensitive' } },
      ];
    }

    if (status === 'ACTIVE') where.isActive = true;
    if (status === 'INACTIVE') where.isActive = false;

    const products = await prisma.product.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ ok: true, products });
  } catch (e) {
    console.error('admin/products GET error', e);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 },
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const {
      name,
      description,
      price,
      costPrice,
      oldPrice,
      imageUrl,
      isActive,
    } = (body || {}) as {
      name?: string;
      description?: string;
      price?: number;
      costPrice?: number;
      oldPrice?: number | null;
      imageUrl?: string | null;
      isActive?: boolean;
    };

    if (!name || typeof price !== 'number' || typeof costPrice !== 'number') {
      return NextResponse.json(
        { error: 'name, price и costPrice обязательны' },
        { status: 400 },
      );
    }

    const baseSlug = generateSlug(name);
    const slug = await getUniqueSlug(baseSlug);

    const product = await prisma.product.create({
      data: {
        name,
        slug,
        description: description || '',
        price: Math.round(price),
        costPrice: Math.round(costPrice),
        oldPrice: oldPrice == null ? null : Math.round(oldPrice),
        imageUrl: imageUrl || null,
        isActive: isActive ?? true,
      },
    });

    return NextResponse.json({ ok: true, product });
  } catch (e) {
    console.error('admin/products POST error', e);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 },
    );
  }
}
