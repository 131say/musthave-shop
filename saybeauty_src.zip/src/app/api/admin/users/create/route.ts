import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import bcrypt from 'bcryptjs';

function normalizePhone(raw: string) {
  return raw.replace(/\s+/g, '');
}
function isValidPhone(p: string) {
  const s = p.startsWith('+') ? p.slice(1) : p;
  return /^[0-9]{10,15}$/.test(s);
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    const { phone, password, name } = (body || {}) as {
      phone?: string;
      password?: string;
      name?: string;
    };

    if (!phone || !password) {
      return NextResponse.json(
        { error: 'phone и password обязательны' },
        { status: 400 },
      );
    }

    const p = normalizePhone(phone);
    if (!isValidPhone(p)) {
      return NextResponse.json({ error: 'Некорректный телефон' }, { status: 400 });
    }
    if (password.length < 4) {
      return NextResponse.json(
        { error: 'Пароль слишком короткий' },
        { status: 400 },
      );
    }

    const exists = await prisma.user.findUnique({
      where: { phone: p },
      select: { id: true },
    });
    if (exists) {
      return NextResponse.json(
        { error: 'Пользователь с таким телефоном уже существует' },
        { status: 400 },
      );
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const created = await prisma.$transaction(async (tx) => {
      const last = await tx.user.findFirst({
        orderBy: { id: 'desc' },
        select: { id: true },
      });
      const nextNum = (last?.id ?? 0) + 1000;
      const referralCode = `SAY${nextNum}`;

      return tx.user.create({
        data: {
          phone: p,
          name: name?.trim() || null,
          role: 'CUSTOMER',
          referralCode,
          bonusBalance: 0,
          slotsTotal: 1,
          passwordHash,
        },
      });
    });

    return NextResponse.json({
      ok: true,
      user: { id: created.id, phone: created.phone },
    });
  } catch (e) {
    console.error('admin users create error', e);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 },
    );
  }
}
