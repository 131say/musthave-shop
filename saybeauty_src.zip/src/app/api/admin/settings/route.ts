export const runtime = "nodejs";
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

async function ensureRow() {
  // IMPORTANT: use upsert to avoid race conditions (HMR / double requests)
  return prisma.appSettings.upsert({
    where: { id: 1 },
    update: {},
    create: { id: 1 },
  });
}

function clampPercent(n: any, def: number) {
  const v = Number(n);
  if (!Number.isFinite(v)) return def;
  return Math.max(0, Math.min(20, Math.round(v)));
}

export async function GET() {
  try {
    const row = await ensureRow();
    return NextResponse.json({ ok: true, settings: row });
  } catch (e: any) {
    console.error("admin/settings GET error", e);
    return NextResponse.json(
      {
        error: "Внутренняя ошибка сервера",
        details: process.env.NODE_ENV !== "production" ? (e?.message || String(e)) : undefined,
      },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    if (!body) return NextResponse.json({ error: "Bad JSON" }, { status: 400 });

    const current = await ensureRow();
    const customerPercent = clampPercent(body.customerPercent, current.customerPercent);
    const inviterPercent = clampPercent(body.inviterPercent, current.inviterPercent);
    const allowFullBonusPay = Boolean(body.allowFullBonusPay);

    // also upsert-safe (if row deleted manually)
    const updated = await prisma.appSettings.upsert({
      where: { id: 1 },
      update: { customerPercent, inviterPercent, allowFullBonusPay },
      create: { id: 1, customerPercent, inviterPercent, allowFullBonusPay },
    });

    return NextResponse.json({ ok: true, settings: updated });
  } catch (e: any) {
    console.error("admin/settings POST error", e);
    return NextResponse.json(
      {
        error: "Внутренняя ошибка сервера",
        details: process.env.NODE_ENV !== "production" ? (e?.message || String(e)) : undefined,
      },
      { status: 500 }
    );
  }
}
