// src/app/api/auth/login/route.ts
import { NextResponse } from 'next/server';

type Role = 'ADMIN' | 'CUSTOMER';

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const { phone, password } = body as {
      phone?: string;
      password?: string;
    };

    if (!phone || !password) {
      return NextResponse.json(
        { error: 'Логин и пароль обязательны' },
        { status: 400 },
      );
    }

    let role: Role | null = null;

    // Тестовые аккаунты
    if (phone === 'admin' && password === 'admin') {
      role = 'ADMIN';
    } else if (phone === 'client' && password === 'client') {
      role = 'CUSTOMER';
    }

    if (!role) {
      return NextResponse.json(
        { error: 'Неверный логин или пароль' },
        { status: 401 },
      );
    }

    const res = NextResponse.json({ ok: true, role });

    // sb_userId можем просто хранить как строку-логин
    res.cookies.set('sb_userId', phone, {
      path: '/',
      sameSite: 'lax',
    });

    res.cookies.set('sb_role', role, {
      path: '/',
      sameSite: 'lax',
    });

    return res;
  } catch (err: any) {
    console.error('Login error', err);
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 },
    );
  }
}
