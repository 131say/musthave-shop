// src/app/api/profile/route.ts
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { phone, referralCode, query } = body as {
      phone?: string;
      referralCode?: string;
      query?: string;
    };

    // Поддержка query параметра (для checkout)
    const searchPhone = query || phone;

    if (!searchPhone && !referralCode) {
      return NextResponse.json(
        { error: 'Укажи телефон или реферальный код' },
        { status: 400 },
      );
    }

    const user = await prisma.user.findFirst({
      where: {
        OR: [
          searchPhone ? { phone: searchPhone } : undefined,
          referralCode ? { referralCode } : undefined,
        ].filter(Boolean) as any,
      },
      include: {
        referrals: true,
        referredBy: true,
        referralEvents: {
          orderBy: { createdAt: 'desc' },
          take: 50,
        },
        orders: {
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'Пользователь не найден' },
        { status: 404 },
      );
    }

    return NextResponse.json({
      profile: {
      id: user.id,
      name: user.name,
      phone: user.phone,
      referralCode: user.referralCode,
      bonusBalance: user.bonusBalance,
      referredBy: user.referredBy
        ? {
            id: user.referredBy.id,
            name: user.referredBy.name,
            phone: user.referredBy.phone,
            referralCode: user.referredBy.referralCode,
          }
        : null,
      referrals: user.referrals.map((r) => ({
        id: r.id,
        name: r.name,
        phone: r.phone,
        referralCode: r.referralCode,
      })),
      referralEvents: user.referralEvents.map((e) => ({
        id: e.id,
        type: e.type,
        amount: e.amount,
        orderId: e.orderId,
        note: e.note,
        createdAt: e.createdAt,
      })),
      orders: user.orders.map((o) => ({
        id: o.id,
        totalAmount: o.totalAmount,
        status: o.status,
        createdAt: o.createdAt,
      })),
      },
    });
  } catch (err) {
    console.error('Profile fetch error', err);
    return NextResponse.json(
      { error: 'Ошибка сервера при получении профиля' },
      { status: 500 },
    );
  }
}

