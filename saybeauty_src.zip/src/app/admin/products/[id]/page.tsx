'use client';

import { useEffect, useMemo, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';

type Product = {
  id: number;
  name: string;
  description: string;
  price: number;
  costPrice: number;
  oldPrice: number | null;
  imageUrl: string | null;
  isActive: boolean;
  slug?: string;
};

export default function AdminProductEditPage() {
  const router = useRouter();
  const params = useParams();
  const id = useMemo(() => Number(params?.id), [params]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [product, setProduct] = useState<Product | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [costPrice, setCostPrice] = useState('');
  const [oldPrice, setOldPrice] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isActive, setIsActive] = useState(true);

  useEffect(() => {
    if (!id || Number.isNaN(id)) {
      setError('Некорректный ID товара');
      setLoading(false);
      return;
    }

    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/admin/products/${id}`);
        const data = await res.json().catch(() => null);
        if (!res.ok) throw new Error(data?.error || 'Ошибка загрузки');

        const p = data.product as Product;
        setProduct(p);
        setName(p.name || '');
        setDescription(p.description || '');
        setPrice(String(p.price ?? ''));
        setCostPrice(String(p.costPrice ?? ''));
        setOldPrice(p.oldPrice == null ? '' : String(p.oldPrice));
        setImageUrl(p.imageUrl || '');
        setIsActive(!!p.isActive);
      } catch (e: any) {
        setError(e?.message || 'Ошибка');
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [id]);

  const onSave = async () => {
    if (!product) return;
    setSaving(true);
    setError(null);
    try {
      const res = await fetch(`/api/admin/products/${product.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          description: description.trim(),
          price: Number(price),
          costPrice: Number(costPrice),
          oldPrice: oldPrice ? Number(oldPrice) : null,
          imageUrl: imageUrl.trim() || null,
          isActive,
        }),
      });

      const data = await res.json().catch(() => null);
      if (!res.ok) throw new Error(data?.error || 'Ошибка сохранения');

      router.replace('/admin/products');
    } catch (e: any) {
      setError(e?.message || 'Ошибка');
    } finally {
      setSaving(false);
    }
  };

  const onDelete = async () => {
    if (!product) return;
    if (!confirm(`Удалить товар "${product.name}"?`)) return;
    setSaving(true);
    setError(null);
    try {
      const res = await fetch(`/api/admin/products/${product.id}`, {
        method: 'DELETE',
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) throw new Error(data?.error || 'Ошибка удаления');
      router.replace('/admin/products');
    } catch (e: any) {
      setError(e?.message || 'Ошибка');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-6 text-sm text-slate-600">
        Загрузка...
      </div>
    );
  }

  if (!product) {
    return (
      <div className="rounded-2xl border border-red-100 bg-red-50 p-6 text-sm text-red-600">
        {error || 'Товар не найден'}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div className="space-y-1">
          <h1 className="text-2xl font-semibold tracking-tight">Редактировать товар</h1>
          <div className="text-xs text-slate-500">
            #{product.id}
            {product.slug ? ` • ${product.slug}` : ''}
          </div>
        </div>
        <button
          onClick={() => router.back()}
          className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm hover:bg-slate-50"
        >
          Назад
        </button>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
          <div>
            <div className="text-xs font-medium text-slate-500">Название*</div>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
            />
          </div>

          <div>
            <div className="text-xs font-medium text-slate-500">Описание</div>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={6}
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
            />
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <div className="text-xs font-medium text-slate-500">Цена*</div>
              <input
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                inputMode="numeric"
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
              />
            </div>
            <div>
              <div className="text-xs font-medium text-slate-500">Старая цена</div>
              <input
                value={oldPrice}
                onChange={(e) => setOldPrice(e.target.value)}
                inputMode="numeric"
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
              />
            </div>
          </div>

          <div>
            <div className="text-xs font-medium text-slate-500">Себестоимость (опт) *</div>
            <input
              value={costPrice}
              onChange={(e) => setCostPrice(e.target.value)}
              inputMode="numeric"
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
              placeholder="3750"
            />
          </div>

          <div>
            <div className="text-xs font-medium text-slate-500">Фото (URL пока)</div>
            <input
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
              placeholder="https://..."
            />
          </div>

          <div className="flex items-center gap-3">
            <input
              id="active"
              type="checkbox"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="h-4 w-4"
            />
            <label htmlFor="active" className="text-sm text-slate-700">
              Товар активен (виден в каталоге)
            </label>
          </div>

          {error && (
            <div className="rounded-xl border border-red-100 bg-red-50 px-3 py-2 text-xs text-red-600">
              {error}
            </div>
          )}

          <div className="flex items-center gap-3">
            <button
              onClick={onSave}
              disabled={saving || !name.trim() || !price || !costPrice}
              className="rounded-xl bg-rose-500 px-4 py-2 text-sm font-medium text-white hover:bg-rose-600 disabled:bg-slate-300"
            >
              {saving ? 'Сохраняю...' : 'Сохранить'}
            </button>
            <button
              onClick={onDelete}
              disabled={saving}
              className="rounded-xl border border-red-200 bg-red-50 px-4 py-2 text-sm font-medium text-red-700 hover:bg-red-100 disabled:opacity-60"
            >
              Удалить
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-3">
          <div className="text-sm font-semibold">Превью</div>
          <div className="rounded-2xl border border-slate-200 overflow-hidden">
            <div className="aspect-[4/3] bg-slate-50">
              {imageUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={imageUrl}
                  alt={name}
                  className="h-full w-full object-cover"
                />
              ) : null}
            </div>
            <div className="p-4 space-y-1">
              <div className="text-sm font-semibold line-clamp-2">
                {name || 'Название товара'}
              </div>
              <div className="text-xs text-slate-500 line-clamp-2">
                {description || 'Описание товара'}
              </div>
              <div className="pt-2 flex items-end justify-between">
                <div>
                  <div className="text-sm font-semibold">
                    {(Number(price) || 0).toLocaleString('ru-RU')} ₸
                  </div>
                  <div className="text-xs text-slate-400 line-through">
                    {oldPrice ? `${Number(oldPrice).toLocaleString('ru-RU')} ₸` : ''}
                  </div>
                </div>
                <div
                  className={`text-[11px] px-2 py-1 rounded-full border ${
                    isActive
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-700'
                      : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  {isActive ? 'Активен' : 'Выключен'}
                </div>
              </div>
            </div>
          </div>
          <div className="text-xs text-slate-500">
            Это превью только для админки (как будет выглядеть карточка).
          </div>
        </div>
      </div>
    </div>
  );
}
