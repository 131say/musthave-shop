// src/app/admin/products/ProductsToolbar.tsx
'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';

export default function ProductsToolbar({
  initialQ,
  initialStatus,
}: {
  initialQ: string;
  initialStatus: string;
}) {
  const router = useRouter();
  const [q, setQ] = useState(initialQ);
  const [status, setStatus] = useState(initialStatus || 'ALL');

  const apply = (next?: { q?: string; status?: string }) => {
    const nq = (next?.q ?? q).trim();
    const ns = (next?.status ?? status).trim();

    const sp = new URLSearchParams();
    if (nq) sp.set('q', nq);
    if (ns && ns !== 'ALL') sp.set('status', ns);

    const qs = sp.toString();
    router.push(qs ? `/admin/products?${qs}` : '/admin/products');
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4">
      <div className="grid gap-3 md:grid-cols-6">
        <div className="md:col-span-4">
          <div className="text-[11px] font-medium text-slate-500">Поиск</div>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter')
                apply({ q: (e.target as HTMLInputElement).value });
            }}
            placeholder="По названию или описанию"
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
          />
        </div>

        <div className="md:col-span-2">
          <div className="text-[11px] font-medium text-slate-500">Статус</div>
          <select
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              apply({ status: e.target.value });
            }}
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
          >
            <option value="ALL">Все</option>
            <option value="ACTIVE">Активные</option>
            <option value="INACTIVE">Выключенные</option>
          </select>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between">
        <button
          onClick={() => {
            setQ('');
            setStatus('ALL');
            router.push('/admin/products');
          }}
          className="text-xs text-slate-500 hover:text-slate-700"
        >
          Сбросить
        </button>
        <div className="text-xs text-slate-500">Enter для поиска</div>
      </div>
    </div>
  );
}
