// src/app/admin/products/new/page.tsx
'use client';

import { useRouter } from 'next/navigation';
import { FormEvent, useState } from 'react';

export default function NewProductPage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [costPrice, setCostPrice] = useState('');
  const [oldPrice, setOldPrice] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/admin/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          description: description.trim(),
          price: Number(price),
          costPrice: Number(costPrice),
          oldPrice: oldPrice ? Number(oldPrice) : null,
          imageUrl: imageUrl.trim() || null,
          isActive,
        }),
      });

      const data = await res.json().catch(() => null);

      if (!res.ok) {
        throw new Error(data?.error || 'Ошибка создания товара');
      }

      router.replace('/admin/products');
    } catch (e: any) {
      setError(e?.message || 'Ошибка');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Создать товар</h1>
        <button
          onClick={() => router.back()}
          className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm hover:bg-slate-50"
        >
          Назад
        </button>
      </div>

      <form
        onSubmit={onSubmit}
        className="max-w-2xl rounded-2xl border border-slate-200 bg-white p-5 space-y-4"
      >
        <div>
          <div className="text-xs font-medium text-slate-500">Название*</div>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
          />
        </div>

        <div>
          <div className="text-xs font-medium text-slate-500">Описание</div>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
          />
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <div className="text-xs font-medium text-slate-500">Цена*</div>
            <input
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              inputMode="numeric"
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
              placeholder="например 8900"
            />
          </div>

          <div>
            <div className="text-xs font-medium text-slate-500">Старая цена</div>
            <input
              value={oldPrice}
              onChange={(e) => setOldPrice(e.target.value)}
              inputMode="numeric"
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
              placeholder="например 9500"
            />
          </div>
        </div>

        <div>
          <div className="text-xs font-medium text-slate-500">Себестоимость (опт) *</div>
          <input
            value={costPrice}
            onChange={(e) => setCostPrice(e.target.value)}
            inputMode="numeric"
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
            placeholder="3750"
          />
        </div>

        <div>
          <div className="text-xs font-medium text-slate-500">Фото (URL пока)</div>
          <input
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
            placeholder="https://..."
          />
        </div>

        <div className="flex items-center gap-3">
          <input
            id="active"
            type="checkbox"
            checked={isActive}
            onChange={(e) => setIsActive(e.target.checked)}
            className="h-4 w-4"
          />
          <label htmlFor="active" className="text-sm text-slate-700">
            Товар активен (виден в каталоге)
          </label>
        </div>

        {error && (
          <div className="rounded-xl border border-red-100 bg-red-50 px-3 py-2 text-xs text-red-600">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading || !name.trim() || !price || !costPrice}
          className="rounded-xl bg-rose-500 px-4 py-2 text-sm font-medium text-white hover:bg-rose-600 disabled:bg-slate-300"
        >
          {loading ? 'Сохраняю...' : 'Создать'}
        </button>
      </form>
    </div>
  );
}
