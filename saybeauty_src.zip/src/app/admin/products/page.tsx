// src/app/admin/products/page.tsx
import Link from 'next/link';
import { prisma } from '@/lib/prisma';
import ProductsToolbar from './ProductsToolbar';
import ProductToggle from './ProductToggle';

export const dynamic = 'force-dynamic';

export default async function AdminProductsPage({
  searchParams,
}: {
  searchParams?: { q?: string; status?: string };
}) {
  const q = (searchParams?.q || '').trim();
  const status = (searchParams?.status || 'ALL').trim();

  const where: any = {};

  if (q) {
    where.OR = [
      { name: { contains: q, mode: 'insensitive' } },
      { description: { contains: q, mode: 'insensitive' } },
    ];
  }

  if (status === 'ACTIVE') where.isActive = true;
  if (status === 'INACTIVE') where.isActive = false;

  const products = await prisma.product.findMany({
    where,
    orderBy: { createdAt: 'desc' },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Товары</h1>
        <Link
          href="/admin/products/new"
          className="rounded-xl bg-rose-500 px-4 py-2 text-sm font-medium text-white hover:bg-rose-600"
        >
          + Создать товар
        </Link>
      </div>

      <ProductsToolbar initialQ={q} initialStatus={status} />

      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
        <div className="grid grid-cols-12 gap-2 border-b border-slate-200 bg-slate-50 px-4 py-3 text-xs font-semibold text-slate-600">
          <div className="col-span-6">Товар</div>
          <div className="col-span-2 text-right">Цена</div>
          <div className="col-span-2 text-right">Старая</div>
          <div className="col-span-2 text-right">Действия</div>
        </div>

        {products.map((p) => (
          <div
            key={p.id}
            className="grid grid-cols-12 items-center gap-2 border-b border-slate-100 px-4 py-3 last:border-b-0"
          >
            <div className="col-span-6 min-w-0">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 overflow-hidden rounded-xl border border-slate-200 bg-slate-50">
                  {/* пока просто плейсхолдер, позже сделаем норм загрузку */}
                  {p.imageUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={p.imageUrl}
                      alt={p.name}
                      className="h-full w-full object-cover"
                    />
                  ) : null}
                </div>
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium">{p.name}</div>
                  <div className="truncate text-xs text-slate-500">#{p.id}</div>
                </div>
              </div>
            </div>

            <div className="col-span-2 text-right text-sm font-semibold">
              {p.price.toLocaleString('ru-RU')} ₸
            </div>

            <div className="col-span-2 text-right text-sm text-slate-500">
              {p.oldPrice ? (
                <span className="line-through">
                  {p.oldPrice.toLocaleString('ru-RU')} ₸
                </span>
              ) : (
                '—'
              )}
            </div>

            <div className="col-span-2 flex items-center justify-end gap-3">
              <Link
                href={`/admin/products/${p.id}`}
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-700 hover:bg-slate-50"
              >
                Редактировать
              </Link>
              <ProductToggle productId={p.id} initialActive={p.isActive} />
            </div>
          </div>
        ))}

        {products.length === 0 && (
          <div className="p-6 text-sm text-slate-600">Ничего не найдено.</div>
        )}
      </div>
    </div>
  );
}
