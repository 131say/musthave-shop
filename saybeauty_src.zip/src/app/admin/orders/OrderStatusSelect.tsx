'use client';

import { useState } from 'react';

export function OrderStatusSelect({
  orderId,
  currentStatus,
}: {
  orderId: number;
  currentStatus: string;
}) {
  const [loading, setLoading] = useState(false);

  // Маппинг для отображения: PROCESSING -> WORKING, CANCELLED -> CANCEL
  const displayStatus =
    currentStatus === 'PROCESSING'
      ? 'WORKING'
      : currentStatus === 'CANCELLED'
        ? 'CANCEL'
        : currentStatus;

  // Обратный маппинг для отправки: WORKING -> PROCESSING, CANCEL -> CANCELLED
  const mapStatusToDB = (status: string) => {
    if (status === 'WORKING') return 'PROCESSING';
    if (status === 'CANCEL') return 'CANCELLED';
    return status;
  };

  const handleChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newStatus = e.target.value;
    const dbStatus = mapStatusToDB(newStatus);

    if (dbStatus === currentStatus) return;

    setLoading(true);
    try {
      const res = await fetch('/api/orders/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId,
          status: dbStatus,
        }),
      });

      const text = await res.text();
      let data: any = null;
      try {
        data = text ? JSON.parse(text) : null;
      } catch {}

      if (!res.ok) {
        throw new Error(data?.error || 'Ошибка обновления статуса');
      }

      // Обновляем страницу для отображения нового статуса
      window.location.reload();
    } catch (err: any) {
      alert(err?.message || 'Ошибка обновления статуса');
      // Возвращаем старое значение при ошибке
      e.target.value = displayStatus;
    } finally {
      setLoading(false);
    }
  };

  return (
    <select
      value={displayStatus}
      onChange={handleChange}
      disabled={loading}
      className="mt-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs outline-none focus:ring-2 focus:ring-rose-100 disabled:opacity-50 disabled:cursor-not-allowed"
    >
      <option value="NEW">NEW</option>
      <option value="WORKING">WORKING</option>
      <option value="DONE">DONE</option>
      <option value="CANCEL">CANCEL</option>
    </select>
  );
}
