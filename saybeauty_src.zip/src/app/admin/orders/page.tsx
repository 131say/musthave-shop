// src/app/admin/orders/page.tsx
import { prisma } from '@/lib/prisma';
import { format } from 'date-fns';
import { ru } from 'date-fns/locale';
import { OrderStatusSelect } from './OrderStatusSelect';
import { OrdersFilters } from './OrdersFilters';

export const dynamic = 'force-dynamic';

function toISOStartOfDay(dateStr?: string | null) {
  if (!dateStr) return null;
  const d = new Date(`${dateStr}T00:00:00.000`);
  return isNaN(d.getTime()) ? null : d.toISOString();
}

function toISOEndOfDay(dateStr?: string | null) {
  if (!dateStr) return null;
  const d = new Date(`${dateStr}T23:59:59.999`);
  return isNaN(d.getTime()) ? null : d.toISOString();
}

export default async function AdminOrdersPage({
  searchParams,
}: {
  searchParams?: { phone?: string; status?: string; from?: string; to?: string };
}) {
  const phone = (searchParams?.phone || '').trim();
  const status = (searchParams?.status || '').trim();
  const from = (searchParams?.from || '').trim();
  const to = (searchParams?.to || '').trim();

  const createdAt: { gte?: Date; lte?: Date } = {};
  const gteISO = toISOStartOfDay(from);
  const lteISO = toISOEndOfDay(to);
  if (gteISO) createdAt.gte = new Date(gteISO);
  if (lteISO) createdAt.lte = new Date(lteISO);

  const where: any = {};
  if (phone) where.customerPhone = { contains: phone };
  if (status && status !== 'ALL') {
    // Маппинг: WORKING -> PROCESSING, CANCEL -> CANCELLED
    if (status === 'WORKING') {
      where.status = 'PROCESSING';
    } else if (status === 'CANCEL') {
      where.status = 'CANCELLED';
    } else {
      where.status = status;
    }
  }
  if (createdAt.gte || createdAt.lte) where.createdAt = createdAt;

  const orders = await prisma.order.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    include: {
      items: {
        include: {
          product: true,
        },
      },
      user: {
        include: {
          referredBy: true,
        },
      },
      referralEvents: true,
    },
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold tracking-tight">Заказы</h1>

      <OrdersFilters
        initialPhone={phone}
        initialStatus={status || 'ALL'}
        initialFrom={from}
        initialTo={to}
      />

      <div className="space-y-4">
        {orders.map((order) => (
          <OrderCard key={order.id} order={order} />
        ))}
        {orders.length === 0 && (
          <div className="rounded-2xl border border-slate-200 bg-white p-6 text-sm text-slate-600">
            Заказов не найдено по выбранным фильтрам.
          </div>
        )}
      </div>
    </div>
  );
}

function statusLabel(s: string) {
  // Маппинг для отображения: PROCESSING -> WORKING, CANCELLED -> CANCEL
  if (s === 'PROCESSING') return 'WORKING';
  if (s === 'CANCELLED') return 'CANCEL';
  return s;
}

function StatusPill({ status }: { status: string }) {
  const base = 'rounded-full px-2 py-0.5 text-[11px] font-medium border';
  const displayStatus = statusLabel(status);
  const cls =
    status === 'NEW'
      ? 'bg-amber-50 text-amber-700 border-amber-200'
      : status === 'PROCESSING'
        ? 'bg-blue-50 text-blue-700 border-blue-200'
        : status === 'DONE'
          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
          : status === 'CANCELLED'
            ? 'bg-rose-50 text-rose-700 border-rose-200'
            : 'bg-slate-50 text-slate-700 border-slate-200';
  return <span className={`${base} ${cls}`}>{displayStatus}</span>;
}

function OrderCard({ order }: { order: any }) {
  const customer = order.user;
  const inviter = customer?.referredBy ?? null;

  const eventsForOrder = order.referralEvents;

  const customerBonusForOrder = eventsForOrder
    .filter((e: any) => e.userId === customer?.id)
    .reduce((sum: number, e: any) => sum + e.amount, 0);

  const inviterBonusForOrder = eventsForOrder
    .filter((e: any) => e.userId === inviter?.id)
    .reduce((sum: number, e: any) => sum + e.amount, 0);

  return (
    <article className="rounded-2xl border border-slate-200 bg-white/80 p-4 text-sm shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">№ {order.id}</span>
            <StatusPill status={order.status} />
          </div>
          <div className="text-xs text-slate-500">
            {format(order.createdAt, 'dd.MM.yyyy HH:mm', {
              locale: ru,
            })}
          </div>
        </div>
        <div className="text-right space-y-1">
          <div className="text-xs text-slate-500">Сумма</div>
          <div className="text-sm font-semibold">
            {order.totalAmount.toLocaleString('ru-RU')} ₸
            {order.bonusSpent > 0 && (
              <div className="mt-1 text-xs text-slate-600">
                <span className="text-emerald-700">−{order.bonusSpent.toLocaleString('ru-RU')} ₸ бонусами</span>
                <span className="ml-2">деньгами: {order.cashPaid.toLocaleString('ru-RU')} ₸</span>
              </div>
            )}
          </div>
          {customer && (
            <div className="mt-1 text-[11px] text-emerald-600">
              Баланс клиента:{' '}
              <span className="font-semibold">
                {customer.bonusBalance.toLocaleString('ru-RU')} ₸
              </span>
            </div>
          )}
          <OrderStatusSelect orderId={order.id} currentStatus={order.status} />
        </div>
      </div>

      <div className="mt-3 grid gap-3 md:grid-cols-[1.2fr,1.4fr]">
        {/* Информация о клиенте + рефералка */}
        <div className="space-y-2">
          <div className="space-y-1">
            <div>
              <span className="text-xs text-slate-400">Имя: </span>
              <span className="text-sm font-medium">{order.customerName}</span>
            </div>
            <div>
              <span className="text-xs text-slate-400">Телефон: </span>
              <span className="text-sm">{order.customerPhone}</span>
            </div>
            {order.customerAddress && (
              <div>
                <span className="text-xs text-slate-400">Адрес: </span>
                <span className="text-sm">{order.customerAddress}</span>
              </div>
            )}
            {order.comment && (
              <div>
                <span className="text-xs text-slate-400">Комментарий: </span>
                <span className="text-sm">{order.comment}</span>
              </div>
            )}
          </div>

          {customer && (
            <div className="rounded-xl bg-rose-50/70 px-3 py-2 text-[11px] text-slate-700">
              <div className="flex items-center justify-between">
                <span className="font-semibold">Реферальная информация</span>
                <span className="text-rose-500">{customer.referralCode}</span>
              </div>
              {inviter ? (
                <div className="mt-1 text-[11px]">
                  <div>
                    Пригласитель:{' '}
                    <span className="font-medium">
                      {inviter.name || inviter.phone}
                    </span>
                  </div>
                  {inviterBonusForOrder !== 0 && (
                    <div>
                      Бонус пригласителю за заказ:{' '}
                      <span className="font-semibold text-emerald-600">
                        {inviterBonusForOrder.toLocaleString('ru-RU')} ₸
                      </span>
                    </div>
                  )}
                </div>
              ) : (
                <div className="mt-1 text-[11px] text-slate-500">
                  Клиент без пригласителя (прямой заход).
                </div>
              )}
              {customerBonusForOrder !== 0 && (
                <div className="mt-1 text-[11px]">
                  Бонус клиента за этот заказ:{' '}
                  <span className="font-semibold text-emerald-600">
                    {customerBonusForOrder.toLocaleString('ru-RU')} ₸
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Товары */}
        <div className="space-y-2">
          <div className="text-xs font-semibold text-slate-500">Товары</div>
          <ul className="space-y-1.5">
            {order.items.map((item: any) => (
              <li
                key={item.id}
                className="flex items-center justify-between gap-2 text-xs"
              >
                <div className="flex-1">
                  <div className="font-medium">
                    {item.product?.name ?? `ID ${item.productId}`}
                  </div>
                  <div className="text-[11px] text-slate-500">
                    {item.priceAtMoment.toLocaleString('ru-RU')} ₸ ×{' '}
                    {item.quantity}
                  </div>
                </div>
                <div className="text-[11px] font-semibold text-slate-800">
                  {item.subtotal.toLocaleString('ru-RU')} ₸
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </article>
  );
}

