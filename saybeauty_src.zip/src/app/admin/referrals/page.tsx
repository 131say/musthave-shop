// src/app/admin/referrals/page.tsx
import Link from 'next/link';
import { getReferrals } from '@/lib/referrals';

function money(n: number) {
  return new Intl.NumberFormat('ru-RU').format(n);
}

export const dynamic = 'force-dynamic';

export default async function ReferralsPage({
  searchParams,
}: {
  searchParams: Promise<{ days?: string }>;
}) {
  const sp = await searchParams;
  const days = Math.max(1, Math.min(90, Number(sp.days || 30)));
  const data = await getReferrals(days);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Реферальная аналитика</h1>
        <div className="flex items-center gap-2">
          {[7, 14, 30, 60, 90].map((d) => (
            <Link
              key={d}
              href={`/admin/referrals?days=${d}`}
              className={`rounded-xl px-3 py-2 text-sm ${
                d === days
                  ? 'bg-rose-500 text-white'
                  : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              {d}д
            </Link>
          ))}
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-3">
        <Block
          title="ТОП по приглашениям"
          subtitle="Кто привёл больше всего людей (всего)"
          rows={data.invitedTop.map((x, idx) => ({
            rank: idx + 1,
            a: x.phone,
            b: x.referralCode,
            c: `${x.invitedCount} чел`,
            href: `/admin/users/${x.userId}`,
          }))}
        />
        <Block
          title="ТОП по обороту команды"
          subtitle={`1 уровень, за ${days} дней`}
          rows={data.teamRevenueTop.map((x, idx) => ({
            rank: idx + 1,
            a: x.phone,
            b: x.referralCode,
            c: `${money(x.teamRevenue)} ₸ / ${x.teamOrders} зак`,
            href: `/admin/users/${x.userId}`,
          }))}
        />
        <Block
          title="ТОП по бонусам пригласителя"
          subtitle={`Сумма бонусов (как пригласитель) за ${days} дней`}
          rows={data.inviterBonusTop.map((x, idx) => ({
            rank: idx + 1,
            a: x.phone,
            b: x.referralCode,
            c: `${money(x.inviterBonus)} ₸`,
            href: `/admin/users/${x.userId}`,
          }))}
        />
      </div>
    </div>
  );
}

function Block({
  title,
  subtitle,
  rows,
}: {
  title: string;
  subtitle: string;
  rows: Array<{ rank: number; a: string; b: string; c: string; href: string }>;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5">
      <div className="text-sm font-semibold">{title}</div>
      <div className="mt-1 text-xs text-slate-500">{subtitle}</div>

      <div className="mt-4 overflow-hidden rounded-xl border border-slate-200">
        <div className="grid grid-cols-[44px_1fr_90px] bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-600">
          <div>#</div>
          <div>Пользователь</div>
          <div className="text-right">Показатель</div>
        </div>
        {rows.length === 0 ? (
          <div className="px-3 py-3 text-sm text-slate-600">Нет данных.</div>
        ) : (
          rows.map((r) => (
            <Link
              key={`${r.rank}-${r.href}`}
              href={r.href}
              className="grid grid-cols-[44px_1fr_90px] items-center gap-2 border-t border-slate-200 px-3 py-2 text-sm hover:bg-slate-50"
            >
              <div className="text-xs text-slate-500">{r.rank}</div>
              <div className="min-w-0">
                <div className="truncate font-medium">{r.a}</div>
                <div className="truncate text-xs text-rose-600">{r.b}</div>
              </div>
              <div className="text-right text-xs font-semibold text-slate-700">{r.c}</div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}

