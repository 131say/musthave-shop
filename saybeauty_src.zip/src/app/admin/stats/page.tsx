import Link from 'next/link';
import { getStats } from '@/lib/stats';

function money(n: number) {
  return new Intl.NumberFormat('ru-RU').format(n);
}

export const dynamic = 'force-dynamic';

export default async function AdminStatsPage({
  searchParams,
}: {
  searchParams: Promise<{ days?: string }>;
}) {
  const sp = await searchParams;
  const days = Math.max(1, Math.min(90, Number(sp.days || 14)));

  let stats;
  try {
    stats = await getStats(days);
  } catch (error: any) {
    return (
      <div className="rounded-2xl border border-red-100 bg-red-50 p-6 text-sm text-red-600">
        Ошибка загрузки статистики: {error?.message || 'Неизвестная ошибка'}
      </div>
    );
  }
  const k = stats.kpis as {
    orders: number;
    revenue: number;
    cogs: number;
    grossProfit: number;
    bonusIssued: number;
    bonusSpent: number;
    bonusLiability: number;
    netProfit: number;
    avgCheck: number;
  };

  const series = (stats.series || []) as Array<{
    date: string;
    revenue: number;
    orders: number;
    cogs: number;
    bonusIssued: number;
  }>;

  const maxRevenue = Math.max(1, ...series.map((x) => x.revenue));

  const liabilityState =
    k.bonusLiability <= 0
      ? { label: 'OK', cls: 'bg-emerald-50 border-emerald-200 text-emerald-700' }
      : k.bonusLiability < k.grossProfit
        ? { label: 'Внимание', cls: 'bg-amber-50 border-amber-200 text-amber-700' }
        : { label: 'Риск', cls: 'bg-rose-50 border-rose-200 text-rose-700' };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Аналитика</h1>
        <div className="flex items-center gap-2">
          {[7, 14, 30, 60, 90].map((d) => (
            <Link
              key={d}
              href={`/admin/stats?days=${d}`}
              className={`rounded-xl px-3 py-2 text-sm ${
                d === days
                  ? 'bg-rose-500 text-white'
                  : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              {d}д
            </Link>
          ))}
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
        <Card title="Оборот" value={`${money(k.revenue)} ₸`} />
        <Card title="Заказы" value={`${k.orders}`} />
        <Card title="Средний чек" value={`${money(k.avgCheck)} ₸`} />
        <Card title="Себестоимость" value={`${money(k.cogs)} ₸`} />
        <Card title="Валовая маржа" value={`${money(k.grossProfit)} ₸`} />
        <Card title="Начислено бонусов" value={`${money(k.bonusIssued)} ₸`} />
        <Card
          title="Бонусный резерв"
          value={`${money(k.bonusLiability)} ₸`}
          extra={
            <span
              className={`mt-2 inline-flex rounded-lg border px-2 py-1 text-xs ${liabilityState.cls}`}
            >
              {liabilityState.label}
            </span>
          }
        />
        <Card title="Чистая прибыль" value={`${money(k.netProfit)} ₸`} />
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-5">
        <div className="flex items-center justify-between">
          <div className="text-sm font-semibold">Оборот по дням</div>
          <div className="text-xs text-slate-500">за последние {days} дней</div>
        </div>

        <div className="mt-4 space-y-2">
          {series.length === 0 ? (
            <div className="text-sm text-slate-600">Нет данных за период.</div>
          ) : (
            series.map((d) => (
              <div key={d.date} className="flex items-center gap-3">
                <div className="w-24 text-xs text-slate-500">{d.date}</div>
                <div className="h-3 flex-1 rounded-full bg-slate-100">
                  <div
                    className="h-3 rounded-full bg-rose-400"
                    style={{ width: `${Math.round((d.revenue / maxRevenue) * 100)}%` }}
                  />
                </div>
                <div className="w-28 text-right text-xs text-slate-700">
                  {money(d.revenue)} ₸
                </div>
                <div className="w-16 text-right text-xs text-slate-500">{d.orders} шт</div>
              </div>
            ))
          )}
        </div>

        <div className="mt-4 text-xs text-slate-500">
          Примечание: если у товара себестоимость = 0, прибыль будет завышена.
        </div>
      </div>
    </div>
  );
}

function Card({
  title,
  value,
  extra,
}: {
  title: string;
  value: string;
  extra?: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4">
      <div className="text-xs font-medium text-slate-500">{title}</div>
      <div className="mt-1 text-xl font-semibold">{value}</div>
      {extra}
    </div>
  );
}

