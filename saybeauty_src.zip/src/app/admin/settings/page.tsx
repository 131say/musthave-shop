"use client";

import { useEffect, useState } from "react";

type Settings = {
  id: number;
  customerPercent: number;
  inviterPercent: number;
  allowFullBonusPay: boolean;
};

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    (async () => {
      setError(null);
      const res = await fetch("/api/admin/settings", { cache: "no-store" as any });
      const data = await res.json().catch(() => null);
      if (!res.ok) {
        setError(data?.error || "Ошибка загрузки настроек");
        return;
      }
      setSettings(data.settings);
    })();
  }, []);

  async function save() {
    if (!settings) return;
    setSaved(false);
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerPercent: settings.customerPercent,
          inviterPercent: settings.inviterPercent,
          allowFullBonusPay: settings.allowFullBonusPay,
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) throw new Error(data?.error || "Ошибка сохранения");
      setSettings(data.settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 1500);
    } catch (e: any) {
      setError(e?.message || "Ошибка");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold tracking-tight">Настройки</h1>
        {saved && <div className="text-sm font-semibold text-emerald-700">Сохранено ✓</div>}
      </div>

      {error && (
        <div className="rounded-2xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>
      )}

      {!settings ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 text-sm text-slate-600">Загрузка…</div>
      ) : (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 space-y-5">
          <div className="text-sm font-semibold">Экономика</div>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <div className="text-xs font-medium text-slate-500">Кэшбэк клиенту (%)</div>
              <input
                type="number"
                min={0}
                max={20}
                value={settings.customerPercent}
                onChange={(e) => setSettings({ ...settings, customerPercent: Number(e.target.value) })}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
              />
              <div className="mt-1 text-[11px] text-slate-500">Рекомендуем: 2–4%</div>
            </div>
            <div>
              <div className="text-xs font-medium text-slate-500">Бонус пригласителю (%)</div>
              <input
                type="number"
                min={0}
                max={20}
                value={settings.inviterPercent}
                onChange={(e) => setSettings({ ...settings, inviterPercent: Number(e.target.value) })}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-rose-100"
              />
              <div className="mt-1 text-[11px] text-slate-500">Рекомендуем: 4–6%</div>
            </div>
          </div>

          <label className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm">
            <input
              type="checkbox"
              checked={settings.allowFullBonusPay}
              onChange={(e) => setSettings({ ...settings, allowFullBonusPay: e.target.checked })}
            />
            Разрешить оплату бонусами до 100%
          </label>

          <button
            onClick={save}
            disabled={loading}
            className="w-full rounded-2xl bg-rose-500 px-4 py-3 text-sm font-semibold text-white hover:bg-rose-600 disabled:bg-slate-300"
          >
            {loading ? "Сохраняем..." : "Сохранить"}
          </button>
        </div>
      )}
    </div>
  );
}
