// src/app/layout.tsx
import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SayBeauty — корейская косметика',
  description:
    'Корейская косметика с доставкой по всему Казахстану и реферальной программой.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ru">
      <body className="min-h-screen bg-gradient-to-b from-rose-50 to-white text-slate-900">
        {children}
      </body>
    </html>
  );
}
