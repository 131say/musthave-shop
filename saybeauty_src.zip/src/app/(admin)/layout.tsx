'use client';

import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useEffect } from 'react';

const menu = [
  { href: '/admin/orders', label: 'Заказы' },
  { href: '/admin/products', label: 'Товары' },
  { href: '/admin/users', label: 'Пользователи' },
  { href: '/admin/stats', label: 'Аналитика' },
  { href: '/admin/referrals', label: 'Рефералы' },
  { href: '/admin/news', label: 'Новости' },
  { href: '/admin/settings', label: 'Настройки' },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();

  // если пользователь "не админ" — выкидываем на / (логин)
  useEffect(() => {
    const role = localStorage.getItem('role');
    if (role !== 'ADMIN') {
      router.replace('/');
    }
  }, [router]);

  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* Левое меню */}
      <aside className="w-64 bg-white border-r border-slate-200 p-4">
        <div className="text-xl font-semibold mb-6">SayBeauty Admin</div>

        <nav className="flex flex-col gap-1">
          {menu.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`px-3 py-2 rounded-lg text-sm transition 
                ${pathname === item.href
                  ? 'bg-rose-500 text-white'
                  : 'text-slate-700 hover:bg-slate-100'
                }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <button
          onClick={() => {
            localStorage.removeItem('role');
            router.replace('/logout');
          }}
          className="mt-6 px-3 py-2 w-full rounded-lg bg-slate-200 text-sm text-slate-700 hover:bg-slate-300"
        >
          Выйти
        </button>
      </aside>

      {/* Контент */}
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
