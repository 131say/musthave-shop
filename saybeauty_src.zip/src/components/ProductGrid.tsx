// src/components/ProductGrid.tsx
'use client';

import { useCart } from '@/components/cart/CartProvider';

type Product = {
  id: number;
  name: string;
  description: string | null;
  price: number;
  oldPrice: number | null;
  imageUrl: string | null;
};

export function ProductGrid({ products }: { products: Product[] }) {
  const { addItem } = useCart();

  return (
    <>
      {products.length === 0 ? (
        <p className="text-sm text-slate-500">
          Товары ещё не добавлены. Как только они появятся, здесь будет каталог.
        </p>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((product) => (
            <article
              key={product.id}
              className="group flex flex-col overflow-hidden rounded-2xl border border-rose-100 bg-white/80 p-3 shadow-sm shadow-rose-50 transition hover:-translate-y-0.5 hover:shadow-md"
            >
              <div className="relative mb-3 h-36 w-full overflow-hidden rounded-xl bg-rose-50">
                <div className="flex h-full items-center justify-center text-[11px] text-rose-300">
                  фото товара
                </div>
              </div>
              <div className="flex-1 space-y-1.5">
                <h4 className="line-clamp-2 text-sm font-medium leading-snug text-slate-800">
                  {product.name}
                </h4>
                {product.description && (
                  <p className="line-clamp-2 text-[11px] text-slate-500">
                    {product.description}
                  </p>
                )}
              </div>
              <div className="mt-3 flex items-end justify-between">
                <div className="space-y-0.5">
                  <div className="text-sm font-semibold text-slate-900">
                    {product.price.toLocaleString('ru-RU')} ₸
                  </div>
                  {product.oldPrice && (
                    <div className="text-[11px] text-slate-400 line-through">
                      {product.oldPrice.toLocaleString('ru-RU')} ₸
                    </div>
                  )}
                </div>
                <button
                  onClick={() =>
                    addItem({
                      productId: product.id,
                      name: product.name,
                      price: product.price,
                      quantity: 1,
                      imageUrl: product.imageUrl,
                    })
                  }
                  className="rounded-full bg-rose-500 px-4 py-1.5 text-xs font-medium text-white shadow-sm shadow-rose-200 transition group-hover:bg-rose-600"
                >
                  В корзину
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </>
  );
}

