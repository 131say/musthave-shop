import { prisma } from '@/lib/prisma';

export default async function NewsBlock() {
  const posts = await prisma.newsPost.findMany({
    where: { isPublished: true },
    orderBy: [{ pinned: 'desc' }, { createdAt: 'desc' }],
    take: 5,
  });

  if (posts.length === 0) return null;

  return (
    <div className="rounded-2xl border border-rose-100 bg-white/70 p-5 backdrop-blur">
      <div className="flex items-center justify-between">
        <div className="text-sm font-semibold">Новости</div>
        <div className="text-xs text-slate-500">SayBeauty</div>
      </div>
      <div className="mt-4 space-y-3">
        {posts.map((p) => (
          <div key={p.id} className="rounded-2xl border border-slate-200 bg-white p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="truncate font-semibold">{p.title}</div>
                <div className="mt-1 line-clamp-3 text-sm text-slate-700 whitespace-pre-wrap">
                  {p.content}
                </div>
              </div>
              {p.pinned && (
                <div className="shrink-0 rounded-lg border border-rose-200 bg-rose-50 px-2 py-1 text-xs font-semibold text-rose-700">
                  📌
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

