// middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Разрешаем без логина:
  if (
    pathname === '/' ||        // страница входа
    pathname === '/logout' ||  // страница выхода
    pathname.startsWith('/api/auth') ||
    pathname.startsWith('/api/products') ||
    pathname.startsWith('/api/orders') ||
    pathname.startsWith('/api/profile') ||
    pathname.startsWith('/_next') ||
    pathname.startsWith('/favicon') ||
    pathname.startsWith('/images') ||
    pathname.startsWith('/public')
  ) {
    return NextResponse.next();
  }

  const userId = req.cookies.get('sb_userId')?.value;
  const role = req.cookies.get('sb_role')?.value;

  // Админка — только ADMIN
  if (pathname.startsWith('/admin')) {
    if (!userId || role !== 'ADMIN') {
      const loginUrl = new URL('/', req.url);
      return NextResponse.redirect(loginUrl);
    }
    return NextResponse.next();
  }

  // Любые другие страницы (home, cabinet, checkout, api/*) — только после логина
  if (!userId) {
    const loginUrl = new URL('/', req.url);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
